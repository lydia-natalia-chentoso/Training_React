# ReactGroup6_ALP

-------------------
Tugas ALP - Group 6
-------------------

Aplikasi mobile sederhana yang dibuat menggunakan React Native, dengan menggunakan source data dari API (https://www.breakingbadapi.com/api/). 
Pada aplikasi ini menampilkan seluruh karakter yang ada didalam "Breaking Bad" TV series. 
Dan bila melakukan seleksi pada salah satu karakter, akan memunculkan informasi detail mengenai karakter yang dipilih.

Anggota :
1. Lydia Natalia (lydia-natalia) : Mengelola Git, menambahkan Navigation, menambahkan redux dan redux-saga
2. Christopher Owen (ChristopherOwen1212) : membuat halaman detail
3. Thaufan Ardi Arafat (ravenbean) : melengkapi halaman about
4. Roslynlia (Roslynlia) : menambahkan redux
5. Yoeka Virya Adhitthana (yukavirya) : Membuat halaman home & pengambilan data (axios)

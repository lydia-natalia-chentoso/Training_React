export default {
    selected: {
        SELECTED: 'SELECTED'
    }
}
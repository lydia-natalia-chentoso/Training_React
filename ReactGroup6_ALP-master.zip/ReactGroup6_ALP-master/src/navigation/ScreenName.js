export default {
    HomeScreen: 'HomeScreen',
    AboutScreen: 'AboutScreen',
    DetailScreen: 'DetailScreen',
}